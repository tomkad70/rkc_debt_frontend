<template>
  <FormSection title="Информация о должнике" icon="👤">
    <FormItem label="ФИО должника">
      <input
          v-model="form.debtor_name"
          type="text"
          class="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-blue-500 focus:border-blue-500 outline-none"
          placeholder="Введите ФИО должника"
      />
    </FormItem>

    <FormItem label="🏠 Адрес должника">
      <input
          v-model="form.debtor_address"
          type="text"
          class="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-blue-500 focus:border-blue-500 outline-none"
          placeholder="Введите адрес должника"
      />
    </FormItem>
  </FormSection>
</template>

<script setup>
import FormSection from '@/components/common/FormSection.vue'
import FormItem from '@/components/common/FormItem.vue'

defineProps({
  form: {
    type: Object,
    required: true
  }
})
</script>